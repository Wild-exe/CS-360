package com.example.drescheetzoption2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageButton;

import com.google.android.material.bottomappbar.BottomAppBar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;

/* TODO: Add custom actionbar view with a dropdown menu
    including a toggle for SMS Notifications and a menu item for
    importing iCalendar feeds.

    TODO: Add SQLite support, add CalendarView to Calendar Fragment,
     getContext from eventCard for EventEditor.

    TODO: Clean code base, Polish UI/UX.
 */


public class MainActivity extends AppCompatActivity {

    // Variables for handling fragments and bottom navbar
    BottomNavigationView bottomNavigationView;
    HomeFragment homeFragment = new HomeFragment();
    CalendarFragment calendarFragment = new CalendarFragment();
    private FloatingActionButton addEvent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // Call AlertDialog if the extra intent is from register activity.
        Intent intent = getIntent();
        String ID = intent.getStringExtra("ID");
        if (ID.equals("Register")) {
            showAlertDialog();
        }

        //Handles floating bottom navbar button
        addEvent = findViewById(R.id.eventBtn);
        addEvent.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openEventEditor();
            }
        });

        // Assigning the bottom navbar id to the navbar variable
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        // Setting the default fragment to home
        getSupportFragmentManager().beginTransaction().replace(R.id.containerMain, homeFragment).commit();
        // Listener and switch case for when the navbar menu items are clicked
        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                switch(item.getItemId()){
                    case R.id.home:
                        getSupportFragmentManager().beginTransaction().replace(R.id.containerMain, homeFragment).commit();
                        return true;
                    case R.id.calendar:
                        getSupportFragmentManager().beginTransaction().replace(R.id.containerMain, calendarFragment).commit();
                        return true;
                }
                return false;
            }
        });
    }


    // Alert Dialog for requesting SMS permissions. Only available upon registration of a new account.
    private void showAlertDialog() {
        AlertDialog dialog = new AlertDialog.Builder(MainActivity.this)
                .setTitle("Enable SMS Notifications?")
                .setMessage("This can be changed later through preferences.")
                .setPositiveButton("Allow", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                })
                .setNeutralButton("Don't Allow", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.dismiss();
                    }
                }).create();
        dialog.show();
    }
    // Method for handling adding event activity.
    public void openEventEditor() {
        Intent intForEdit = new Intent(this, EventEditor.class);
        startActivity(intForEdit);
    }
}