package com.example.drescheetzoption2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventHolder> {
    private HomeFragment eContext;
    private String[] eSummary;
    private String[] eDescription;
    //Holder for the event_card grids for displaying each event.
    public static class EventHolder extends RecyclerView.ViewHolder {
        TextView summary;
        TextView description;
        // Assigns the Id in the grid textViews to the TextView objects.
        public EventHolder(View itemView) {
            super(itemView);
            this.summary = (TextView) itemView.findViewById(R.id.textSummary);
            this.description = (TextView) itemView.findViewById(R.id.textDescription);
        }
    }
    // Constructor for the event_cards
    public EventAdapter(HomeFragment eContext, String[] summary, String[] description) {
        this.eContext = eContext;
        this.eSummary = summary;
        this.eDescription = description;
    }
    // Initializes ViewHolder (EventHolder once Adapter is instantiated)
    @Override
    public EventHolder onCreateViewHolder(ViewGroup parent,
                                           int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_card, parent, false);
        EventHolder eventHolder = new EventHolder(view);
        return eventHolder;
    }
    // Method to update RecyclerView with the data at each i position in Array
    @Override
    public void onBindViewHolder(final EventHolder holder, final int i) {
        holder.summary.setText(eSummary[i]);
        holder.description.setText(eDescription[i]);
    }

    // Returns the number of items in the adapter
    @Override
    public int getItemCount() {
        return eSummary.length;
    }
}