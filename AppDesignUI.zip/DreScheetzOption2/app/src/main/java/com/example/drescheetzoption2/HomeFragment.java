package com.example.drescheetzoption2;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;
import android.os.Bundle;

// Fragment of the Main Activity to provide separate views of the same data (Calendar not yet implemented.)
public class HomeFragment extends Fragment {
    private RecyclerView recyclerView;

    // Dummy data to be replaced with database events, times and dates will also be included.
    String [] summaryArray = {"Event Title 1","Event Title 2","Event Title 3","Event Title 4"};
    String [] descriptionArray = {"This is an example description 1", "This is an example description 2",
                                    "This is an example description 3", "This is an example description 4"};
    EventAdapter eventAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        // Handling the RecyclerView in xml along with it's adapter.
        recyclerView = view.findViewById(R.id.recyclerView);
        eventAdapter = new EventAdapter(HomeFragment.this, summaryArray, descriptionArray);
        recyclerView.setAdapter(eventAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        return view;

    }
}