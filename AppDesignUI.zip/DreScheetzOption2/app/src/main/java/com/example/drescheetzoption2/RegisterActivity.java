package com.example.drescheetzoption2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class RegisterActivity extends AppCompatActivity {
    private Button newRegisterBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_register);

        newRegisterBtn = findViewById(R.id.newRegisterBtn);
        newRegisterBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openMainActivity();
            }
        });

    }
    // Passing the intent and extra for the AlertDialog for SMS Notifications in addition to starting the main activity.
    public void openMainActivity() {
        String ID = "Register";
        Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("ID", ID);
        startActivity(intent);
    }
}