package com.example.drescheetzoption2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

public class EventEditor extends AppCompatActivity {
    private Button cancelBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_editor);

        cancelBtn = findViewById(R.id.cancelBtn);
        // When clicked
        cancelBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                // Call Activity Method
                openMainActivity();
            }
        });
    }

    // Activity Method
    public void openMainActivity() {
        //Currently unused; however, the extra intent is to prevent crash.
        String ID = "Activity";

        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("ID", ID);
        startActivity(intent);
    }
}