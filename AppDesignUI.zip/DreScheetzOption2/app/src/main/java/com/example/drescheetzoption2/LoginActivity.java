package com.example.drescheetzoption2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LoginActivity extends AppCompatActivity {
    // Variable for buttons by button ID's
    private Button loginbtn;
    private Button registerbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Assign the id to the variable for the button
        loginbtn = findViewById(R.id.loginBtn);
        // When clicked
        loginbtn.setOnClickListener(new View.OnClickListener(){
           @Override
           public void onClick(View v) {
               // Call Activity Method
               openMainActivity();
           }
        });

        registerbtn = findViewById(R.id.registerBtn);
        registerbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                openRegisterActivity();
            }
        });

    }
    // Activity Method
    public void openMainActivity() {
        //Currently unused; however, the extra intent is to prevent crash.
        String ID = "Login";

        Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("ID", ID);
        startActivity(intent);
    }
    public void openRegisterActivity() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}