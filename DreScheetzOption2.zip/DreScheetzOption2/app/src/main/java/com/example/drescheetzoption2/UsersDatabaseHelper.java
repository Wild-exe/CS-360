package com.example.drescheetzoption2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class UsersDatabaseHelper extends SQLiteOpenHelper {
    public static final String USERS_TABLE = "USER_TABLE";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_PASSWORD = "PASSWORD";
    public  static final String COLUMN_PHONE = "PHONE";
    public static final String COLUMN_USER_ID = "USER_ID";

    // Database Constructor
    public UsersDatabaseHelper(@Nullable Context context) {
        super(context, "users.db", null, 1);
    }
    // Create new database
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createUsersTable = "CREATE TABLE " + USERS_TABLE + " (" + COLUMN_USER_ID + " INTEGER PRIMARY KEY " +
                "AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_PASSWORD + " TEXT, "
                + COLUMN_PHONE + " TEXT)";
        sqLiteDatabase.execSQL(createUsersTable);
    }

    // Add user for the provided content
    public void addUser(Users user) {
        SQLiteDatabase db = this.getWritableDatabase(); // Need to write/
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_USERNAME, user.getUsername());
        cv.put(COLUMN_PASSWORD, user.getPassword());
        cv.put(COLUMN_PHONE, user.getPhone());
        db.insert(USERS_TABLE, null, cv);
        db.close();
    }

    // Query by provided value and column of the database.
    public boolean querySingleColumn(String queryTerm, String column) {
        String[] columns = { COLUMN_USER_ID };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = column + " = ?";
        String[] selectionArgs = {queryTerm};
        Cursor cursor = db.query(USERS_TABLE, columns, selection, selectionArgs,null,null, null);
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        return cursorCount > 0;
    }

    // Checks if user and password both exist in database for logging in.
    public boolean queryUserExists(String username, String password) {
        String[] columns = { COLUMN_USER_ID };
        SQLiteDatabase db = this.getReadableDatabase();
        String selection = COLUMN_USERNAME + " = ?" + " AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(USERS_TABLE, columns, selection, selectionArgs,null,null, null);
        int cursorCount = cursor.getCount();
        cursor.close();
        db.close();
        return cursorCount > 0;
    }
    // Udates the phone useful for users who may change phone numbers/
    public void updateDBPhone(String username, String phone) {
        SQLiteDatabase db  = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_PHONE, phone);
        db.update(USERS_TABLE, cv, "username ='" + username + "'", null);
        db.close();
    }

    // Called if database version change is necessary
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {}
}
