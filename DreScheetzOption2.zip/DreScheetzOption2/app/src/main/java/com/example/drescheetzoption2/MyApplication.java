package com.example.drescheetzoption2;

import android.app.Application;
import android.content.Context;

// Singleton to provide Application context to Events class AlarmManager.
public class MyApplication extends Application {

    // Because this is an extension of Application I do not think the warning applies.
    private static Context mContext;

    @Override
    public void onCreate() {
        super.onCreate();
        mContext = getApplicationContext();
    }

    public static Context getContext() {
        return mContext;
    }
}
