package com.example.drescheetzoption2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Fragment of the Main Activity to provide separate views of the same data (Calendar not yet implemented.)
public class HomeFragment extends Fragment {
    RecyclerView recyclerView;
    EventAdapter eventAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        // Handling the RecyclerView in xml along with it's adapter.
        recyclerView = view.findViewById(R.id.recyclerView);
        loadRecyclerView(view);
        return view;
    }

    private void loadRecyclerView(View view) {
        EventsDatabaseHelper eventsDatabaseHelper = new EventsDatabaseHelper(view.getContext());
        List<Events> eventsList  = eventsDatabaseHelper.readAllEvents();
        eventAdapter = new EventAdapter(eventsList);
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        recyclerView.setAdapter(eventAdapter);
    }
}


