package com.example.drescheetzoption2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class EventsDatabaseHelper extends SQLiteOpenHelper {
    public static final String EVENT_TABLE = "EVENT_TABLE";
    public static final String COLUMN_SUMMARY = "SUMMARY";
    public static final String COLUMN_DESCRIPTION = "DESCRIPTION";
    public  static final String COLUMN_EVENT_DATE_TIME = "EVENT_DATE_TIME";
    public static final String COLUMN_NOTIFICATION_DATE_TIME = "NOTIFICATION_DATE_TIME";
    public static final String COLUMN_ID = "ID";

    // Database Constructor
    public EventsDatabaseHelper(@Nullable Context context) {
        super(context, "events.db", null, 1);
    }

    // Create new database
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createEventsTable = "CREATE TABLE " + EVENT_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY " +
                "AUTOINCREMENT, " + COLUMN_SUMMARY + " TEXT, " + COLUMN_DESCRIPTION + " TEXT, "
                + COLUMN_EVENT_DATE_TIME + " TEXT, " + COLUMN_NOTIFICATION_DATE_TIME + " TEXT)";
        sqLiteDatabase.execSQL(createEventsTable);
    }
    // Called if database version change is necessary
    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }

    public long addEvent(Events events) {
       SQLiteDatabase db = this.getWritableDatabase();
       // Values to be put into the database.
       ContentValues cv = new ContentValues();
       cv.put(COLUMN_SUMMARY, events.getSummary());
       cv.put(COLUMN_DESCRIPTION, events.getDescription());
       cv.put(COLUMN_EVENT_DATE_TIME, events.getEventDateTime());
       cv.put(COLUMN_NOTIFICATION_DATE_TIME, events.getNotifDateTime());
       long id = db.insert(EVENT_TABLE, null, cv);
       db.close();
       return id;
    }

    public List<Events> readAllEvents(){
        List<Events> returnList = new ArrayList<>();
        String queryString = "SELECT * FROM " + EVENT_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()){
        // Loop results while there is a next line.
            do {
                int eventID = cursor.getInt(0);
                String eventSummary = cursor.getString(1);
                String eventDescription = cursor.getString(2);
                String eventDateTime = cursor.getString(3);
                String notifDateTime = cursor.getString(4);

                Events newEvent = new Events(eventID, eventSummary, eventDescription, eventDateTime, notifDateTime);
                returnList.add(newEvent);

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return returnList;
    }

    public void updateEvent(Events event) {
        SQLiteDatabase db  = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_SUMMARY, event.getSummary());
        cv.put(COLUMN_DESCRIPTION, event.getDescription());
        cv.put(COLUMN_EVENT_DATE_TIME, event.getEventDateTime());
        cv.put(COLUMN_NOTIFICATION_DATE_TIME, event.getNotifDateTime());
        db.update(EVENT_TABLE, cv, "id ='" + event.getEventId() + "'", null);
        db.close();
    }

    public void deleteEvent (Events event){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(EVENT_TABLE, "id ='" + event.getEventId() + "'", null);
        db.close();
    }
}
