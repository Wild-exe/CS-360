package com.example.drescheetzoption2;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;

public class EventEditor extends AppCompatActivity {
    private Button btnAddSave, btnAddCancel;
    private EditText etSummary, etDescription;
    private TextView tvEventDate, tvEventTime, tvNotifDate, tvNotifTime;
    LocalDate eventDate, notifDate;
    LocalTime eventTime, notifTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_editor);
        etSummary = findViewById(R.id.etSummary);
        etDescription = findViewById(R.id.etDescription);
        tvEventDate = findViewById(R.id.tvAddEventDate);
        tvEventTime = findViewById(R.id.tvAddEventTime);
        tvNotifDate = findViewById(R.id.tvAddNotifDate);
        tvNotifTime= findViewById(R.id.tvAddNotifTime);
        btnAddSave = findViewById(R.id.btnAddSave);
        btnAddCancel = findViewById(R.id.btnAddCancel);
        btnAddSave.setEnabled(false);

        // Listener for Event Title (Summary)
        etSummary.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            //Enables button with input.
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                btnAddSave.setEnabled(charSequence.length() > 0);
            }
            @Override
            public void afterTextChanged(Editable editable) {}
        });
        // TODO: default to notification before event or make it required.
        // On click save event.
        btnAddSave.setOnClickListener(v -> {
            Events event;

            //Sets default values if not selected.
            String description = !etDescription.getText().toString().isEmpty() ? etDescription.getText().toString(): "";
            String eventDateTime = eventTime != null && eventDate != null ?
                    formatDateTime(eventTime,eventDate).toString(): LocalDateTime.now().plusDays(4).toString();
            String notifDateTime = notifTime != null && notifDate != null ?
                    formatDateTime(notifTime,notifDate).toString(): LocalDateTime.now().plusDays(3).toString();
            //Instantiate event then send to db while setting alarm.
            event = new Events(-1, etSummary.getText().toString(), description, eventDateTime, notifDateTime);
            EventsDatabaseHelper eventsDatabaseHelper = new EventsDatabaseHelper(EventEditor.this);
            event.setAlarmSMS(formatDateTime(notifTime,notifDate), (int) eventsDatabaseHelper.addEvent(event), etSummary.getText().toString(), eventDateTime );
            openMainActivity();
        });

        btnAddCancel.setOnClickListener(v -> {
            openMainActivity();     // Call Activity Method
        });
        tvEventDate.setOnClickListener(this::showEventDateDialog);
        tvEventTime.setOnClickListener(this::showEventTimeDialog);
        tvNotifDate.setOnClickListener(this::showNotifDateDialog);
        tvNotifTime.setOnClickListener(this::showNotifTimeDialog);
    }

    //Picker methods
    private void showEventTimeDialog(View view) {
        FragmentManager manager = ((AppCompatActivity)view.getContext()).getSupportFragmentManager();
        MaterialTimePicker addEventTimePicker = new MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(LocalTime.now().getHour())
                .setMinute(LocalTime.now().getMinute())
                .setTitleText("Time of Event")
                .build();
        addEventTimePicker.show(manager, "EVENT_TIME_Add");

        // Set variables per picker.
        addEventTimePicker.addOnPositiveButtonClickListener(view1 -> {
            tvEventTime.setText(LocalTime.of(addEventTimePicker.getHour(), addEventTimePicker.getMinute()).toString());
            eventTime = LocalTime.of(addEventTimePicker.getHour(), addEventTimePicker.getMinute());
        });
    }

    private void showEventDateDialog(View view) {
        FragmentManager manager = ((AppCompatActivity)view.getContext()).getSupportFragmentManager();
        MaterialDatePicker<Long> addEventDatePicker = MaterialDatePicker.Builder
                .datePicker()
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .setTitleText("Select Date")
                .build();
        addEventDatePicker.show(manager, "EVENT_DATE_ADD");

        addEventDatePicker.addOnPositiveButtonClickListener(selection -> {
            Instant pickedDate = Instant.ofEpochMilli(selection);
            LocalDate localDate = pickedDate.atZone(ZoneId.systemDefault()).toLocalDate().plusDays(1);
            tvEventDate.setText(localDate.toString());
            eventDate = localDate;
        });
    }

    private void showNotifTimeDialog(View view) {
        FragmentManager manager = ((AppCompatActivity)view.getContext()).getSupportFragmentManager();
        MaterialTimePicker addNotifTimePicker = new MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(LocalTime.now().getHour())
                .setMinute(LocalTime.now().getMinute())
                .setTitleText("Time of Event")
                .build();
        addNotifTimePicker.show(manager, "NOTIF_TIME_ADD");

        addNotifTimePicker.addOnPositiveButtonClickListener(view1 -> {
            tvNotifTime.setText(LocalTime.of(addNotifTimePicker.getHour(), addNotifTimePicker.getMinute()).toString());
            notifTime = LocalTime.of(addNotifTimePicker.getHour(), addNotifTimePicker.getMinute());
        });
    }

    private void showNotifDateDialog(View view) {
        FragmentManager manager = ((AppCompatActivity)view.getContext()).getSupportFragmentManager();
        MaterialDatePicker<Long> addNotifDatePicker = MaterialDatePicker.Builder
                .datePicker()
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .setTitleText("Select Date")
                .build();
        addNotifDatePicker.show(manager, "NOTIF_DATE_ADD");

        addNotifDatePicker.addOnPositiveButtonClickListener(selection -> {
            Instant pickedDate = Instant.ofEpochMilli(selection);
            LocalDate localDate = pickedDate.atZone(ZoneId.systemDefault()).toLocalDate().plusDays(1);
            tvNotifDate.setText(localDate.toString());
            notifDate = localDate;
        });
    }

    private LocalDateTime formatDateTime(LocalTime localTime, LocalDate localDate) {
        return LocalDateTime.of(localDate, localTime);
    }

    // Activity Method
    public void openMainActivity() {
        //Currently unused; however, the extra intent is to prevent crash.
        String ID = "Activity";
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("ID", ID);
        startActivity(intent);
    }
}