package com.example.drescheetzoption2;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
/*
    TODO: add CalendarView to Calendar Fragment,
    TODO: Clean code base, Polish UI/UX.

    TODO fix time to HH:MM
    TODO Alarm Manager
 */
public class MainActivity extends AppCompatActivity {
    // Variables for handling fragments and bottom navbar
    private String username;
    BottomNavigationView bottomNavigationView;
    HomeFragment homeFragment = new HomeFragment();
    CalendarFragment calendarFragment = new CalendarFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Call AlertDialog if the extra intent is from register activity.
        Intent intent = getIntent();
        String ID = intent.getStringExtra("ID");
        username = intent.getStringExtra("username");
        if (ID.equals("Register")) {
            // Alert Dialog for requesting SMS permissions. Only available upon registration of a new account.
            int SMS_PERMISSION_CODE = 1;
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);

        }

        //Handles floating bottom navbar button
        FloatingActionButton addEvent = findViewById(R.id.eventBtn);
        addEvent.setOnClickListener(v -> openEventEditor());
        // Assigning the bottom navbar id to the navbar variable
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        // Setting the default fragment to home
        getSupportFragmentManager().beginTransaction().replace(R.id.containerMain, homeFragment).commit();
        // Listener and switch case for when the navbar menu items are clicked
        bottomNavigationView.setOnItemSelectedListener(item -> {
            switch(item.getItemId()){
                case R.id.home:
                    getSupportFragmentManager().beginTransaction().replace(R.id.containerMain, homeFragment).commit();
                    return true;
                case R.id.calendar:
                    getSupportFragmentManager().beginTransaction().replace(R.id.containerMain, calendarFragment).commit();
                    return true;
                default:
                    throw new IllegalStateException("Unexpected value: " + item.getItemId());
            }
        });
    }
    // Adds SMS Notification and iCal feed to action bar and instantiates.
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.action_menu, menu);
        return true;
    }

    // Update phone number from action bar menu.
    public void updatePhone(MenuItem item) {
        UsersDatabaseHelper usersDatabaseHelper = new UsersDatabaseHelper(this);
        EditText etUpdatePhone = new EditText(this);
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Update Phone Number")
                .setMessage("Enter phone number to receive SMS messages")
                .setView(etUpdatePhone)
                .setPositiveButton("OK", (dialogInterface, i) -> {
                    String phone = etUpdatePhone.getText().toString();
                    usersDatabaseHelper.updateDBPhone(username, phone);
                    SharedPreferences.Editor editor = getSharedPreferences("userpref", MODE_PRIVATE).edit();
                    editor.putString("smsPhone", phone);
                    editor.apply();
                })
                .setNegativeButton("Cancel", null)
                .create();
        dialog.show();
    }
    // Clears shared preferences from action bar menu
    public void clearPreferences(MenuItem menuItem){
        SharedPreferences.Editor editor = getSharedPreferences("userpref", MODE_PRIVATE).edit();
        editor.clear().apply();
    }

    // Method for handling adding event activity.
    public void openEventEditor() {
        Intent intForEdit = new Intent(this, EventEditor.class);
        startActivity(intForEdit);
    }

    // Creates new permission dialog if permission not granted.
    public void smsNotifUpdate(MenuItem item) {
        String permission = Manifest.permission.SEND_SMS;
        int grant = ContextCompat.checkSelfPermission(this, permission);
        if (grant != PackageManager.PERMISSION_GRANTED) {
            String[] permission_list = new String[1];
            permission_list[0] = permission;
            ActivityCompat.requestPermissions(this, permission_list, 1);
        } else {
            Toast.makeText(this, "Permission Already Granted", Toast.LENGTH_SHORT).show();
        }
    }
}
