package com.example.drescheetzoption2;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.timepicker.MaterialTimePicker;
import com.google.android.material.timepicker.TimeFormat;

import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.List;

// TODO can't update notification to after event
public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventsVH> {
    List<Events> eventsList; // Contains Event data
    private int expandedEvent; // Variable for assigning which event was last expanded.

    public EventAdapter( List<Events> eventsList) {
        this.eventsList = eventsList;
    }

    @NonNull
    @Override
    public EventsVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.event_card, parent, false);
        return new EventsVH(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventAdapter.EventsVH holder, int position) {
        Events events = eventsList.get(position);
        holder.etSummary.setText(events.getSummary());
        holder.etDescription.setText(events.getDescription());
        holder.tvEventDate.setText(events.getEventDate().toString());
        holder.tvEventTime.setText(events.getEventTime().toString());
        holder.tvNotifDate.setText(events.getNotifDate().toString());
        holder.tvNotifTime.setText(events.getNotifTime().toString());

        // Uses the events isExpandle as and if stateent to control the expanded event.
        boolean isExpandable = eventsList.get(position).isExpandable();
        holder.expandableLayout.setVisibility(isExpandable ? View.VISIBLE : View.GONE);
        holder.expandableLayout.setBackgroundColor(isExpandable ?
                Color.parseColor("#FFE5E9F1") : Color.parseColor("#FFFFFFFF"));
        holder.eventLayout.setBackgroundColor(isExpandable ?
                Color.parseColor("#FFE5E9F1") : Color.parseColor("#FFFFFFFF"));
        holder.etSummary.setEnabled(isExpandable);
        holder.etSummary.setEnabled(isExpandable);
        holder.tvEventTime.setClickable(isExpandable);
        holder.tvEventDate.setClickable(isExpandable);
    }

    // Returns the number of items in the adapter
    @Override
    public int getItemCount() {
        return eventsList.size();
    }

    public class EventsVH extends RecyclerView.ViewHolder {
        EditText etSummary, etDescription;
        TextView tvEventTime, tvEventDate, tvNotifTime, tvNotifDate;
        ImageButton btnDelete, btnEdit;
        RelativeLayout eventLayout;
        GridLayout expandableLayout;


        public EventsVH(@NonNull View itemView) {
            super(itemView);
            etSummary = itemView.findViewById(R.id.textSummary);
            etDescription = itemView.findViewById(R.id.textDescription);
            tvEventTime = itemView.findViewById(R.id.tvEventTime);
            tvEventDate = itemView.findViewById(R.id.tvEventDate);
            tvNotifTime = itemView.findViewById(R.id.tvNotifTime);
            tvNotifDate = itemView.findViewById(R.id.tvNotifDate);

            btnDelete = itemView.findViewById(R.id.deleteBtn);
            btnEdit = itemView.findViewById(R.id.editBtn);

            eventLayout = itemView.findViewById(R.id.eventLayout);
            expandableLayout = itemView.findViewById(R.id.expandableLayout);

            // On Click methods.
            eventLayout.setOnClickListener(view -> expandEventOnClick());
            btnDelete.setOnClickListener(this::deleteEventOnClick);
            btnEdit.setOnClickListener(this::updateEventOnClick);
            tvEventDate.setOnClickListener(EventAdapter.this::showEventDateDialog);
            tvEventTime.setOnClickListener(EventAdapter.this::showEventTimeDialog);
            tvNotifDate.setOnClickListener(EventAdapter.this::showNotifDateDialog);
            tvNotifTime.setOnClickListener(EventAdapter.this::showNotifTimeDialog);
        }

        private void expandEventOnClick() {
            Events event = eventsList.get(getAdapterPosition());
            // Resets date and Time in event card if the event was not updated with save button.
            event.resetEventDateTime(event.getEventDate(), event.getEventTime(), event.getEventDateTime());
            event.resetNotifDateTime(event.getNotifDate(), event.getNotifTime(), event.getNotifDateTime());
            event.setExpandable(!event.isExpandable());
            if (expandedEvent != -1 && expandedEvent != getAdapterPosition()) {
                Events e = eventsList.get(expandedEvent);
                e.resetNotifDateTime(e.getNotifDate(), e.getNotifTime(), e.getNotifDateTime());
                e.resetEventDateTime(e.getEventDate(), e.getEventTime(),e.getEventDateTime());
                e.setExpandable(false);
                notifyItemChanged(expandedEvent);
            }
            notifyItemChanged(getAdapterPosition());
            expandedEvent = getAdapterPosition();
        }

        //Updates the event in the database along with its alarm.
        private void updateEventOnClick(View view) {
            String summary = etSummary.getText().toString();
            String description = etDescription.getText().toString();
            Events event = eventsList.get(getExpandedEvent());

            // Format from picker before updating db.
            String eventDateTime = formatDateTime(event.getEventTime(),event.getEventDate()).toString();
            String notifDateTime = formatDateTime(event.getNotifTime(),event.getNotifDate()).toString();

            // Set Alarm
            event.setAlarmSMS(formatDateTime(event.getNotifTime(),event.getNotifDate()), event.getEventId(), summary, description);

            // If any of the events values were altered, get values then update.
            if (!summary.equals(event.getSummary()) || !description.equals(event.getDescription())
                    || !eventDateTime.equals(event.getEventDateTime()) || !notifDateTime.equals(event.getNotifDateTime())) {
                event.setSummary(summary);
                event.setDescription(description);
                event.setEventDateTime(eventDateTime);
                event.setNotifDateTime(notifDateTime);
                EventsDatabaseHelper eventsDatabaseHelper = new EventsDatabaseHelper(view.getContext());
                eventsDatabaseHelper.updateEvent(event);

                // Notifies Adapter of this items change.
                notifyItemChanged(getExpandedEvent());
            }
        }

        // Delete by currently selected events ID.
        private void deleteEventOnClick(View view) {
            EventsDatabaseHelper eventsDatabaseHelper = new EventsDatabaseHelper(view.getContext());
            eventsDatabaseHelper.deleteEvent(eventsList.get(getExpandedEvent()));
            Toast.makeText(view.getContext(), "Event Deleted", Toast.LENGTH_SHORT).show();
            eventsList.remove(getExpandedEvent());
            notifyItemRemoved(getExpandedEvent());
            expandedEvent = -1;
        }

        public int getExpandedEvent() { return expandedEvent; }
    }

    // Pickers for setting Times and Dates.
    private void showEventTimeDialog(View view) {
        FragmentManager manager = ((AppCompatActivity)view.getContext()).getSupportFragmentManager();
        MaterialTimePicker eventTimePicker = new MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(LocalTime.now().getHour())
                .setMinute(LocalTime.now().getMinute())
                .setTitleText("Time of Event")
                .build();
        eventTimePicker.show(manager, "EVENT_TIME");

        eventTimePicker.addOnPositiveButtonClickListener(view1 -> {
            Events event = eventsList.get(expandedEvent);
            event.setEventTime(LocalTime.of(eventTimePicker.getHour(), eventTimePicker.getMinute()));
            notifyItemChanged(expandedEvent);
        });
    }

    private void showEventDateDialog(View view) {
        FragmentManager manager = ((AppCompatActivity)view.getContext()).getSupportFragmentManager();
        MaterialDatePicker<Long> eventDatePicker = MaterialDatePicker.Builder
                .datePicker()
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .setTitleText("Select Date")
                .build();
        eventDatePicker.show(manager, "EVENT_DATE");

        eventDatePicker.addOnPositiveButtonClickListener(selection -> {
           Instant pickedDate = Instant.ofEpochMilli(selection);
            LocalDate localDate = pickedDate.atZone(ZoneId.systemDefault()).toLocalDate().plusDays(1);
            Events event = eventsList.get(expandedEvent);
            event.setEventDate(localDate);
            notifyItemChanged(expandedEvent);
        });
    }

    private void showNotifTimeDialog(View view) {
        FragmentManager manager = ((AppCompatActivity)view.getContext()).getSupportFragmentManager();
        MaterialTimePicker notifTimePicker = new MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_12H)
                .setHour(LocalTime.now().getHour())
                .setMinute(LocalTime.now().getMinute())
                .setTitleText("Time of Event")
                .build();
        notifTimePicker.show(manager, "NOTIF_TIME");

        notifTimePicker.addOnPositiveButtonClickListener(view1 -> {
            Events event = eventsList.get(expandedEvent);
            event.setNotifTime(LocalTime.of(notifTimePicker.getHour(), notifTimePicker.getMinute()));
            notifyItemChanged(expandedEvent);
        });
    }

    private void showNotifDateDialog(View view) {
        FragmentManager manager = ((AppCompatActivity)view.getContext()).getSupportFragmentManager();
        MaterialDatePicker<Long> notifDatePicker = MaterialDatePicker.Builder
                .datePicker()
                .setSelection(MaterialDatePicker.todayInUtcMilliseconds())
                .setTitleText("Select Date")
                .build();
        notifDatePicker.show(manager, "NOTIF_DATE");

        notifDatePicker.addOnPositiveButtonClickListener(selection -> {
            Instant pickedDate = Instant.ofEpochMilli(selection);
            LocalDate localDate = pickedDate.atZone(ZoneId.systemDefault()).toLocalDate().plusDays(1);
            Events event = eventsList.get(expandedEvent);
            event.setNotifDate(localDate);
            notifyItemChanged(expandedEvent);
        });
    }

    private LocalDateTime formatDateTime(LocalTime localTime, LocalDate localDate) {
        return LocalDateTime.of(localDate, localTime);
    }
}








