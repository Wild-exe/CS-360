package com.example.drescheetzoption2;

import androidx.annotation.NonNull;

public class Users {
    private final int userId;
    private String username, password, phone;
    // Constructor for users
    public Users(int userId, String username, String password, String phone) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.phone = phone;
    }
    // Getters and Setters
    public int getUserId() { return userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    @NonNull
    @Override
    public String toString() {
        return "Users{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", phone='" + phone + '\'' +
                '}';
    }
}
