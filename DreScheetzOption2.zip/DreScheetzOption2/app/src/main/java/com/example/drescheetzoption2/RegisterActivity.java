package com.example.drescheetzoption2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Button btnNewRegister = findViewById(R.id.btnNewRegister);
        EditText etRegisterUserName = findViewById(R.id.etRegisterUsername);
        EditText etRegisterPassword = findViewById(R.id.etRegisterPassword);
        EditText etRegisterPhone = findViewById(R.id.etRegisterPhone);
        TextView tvUsernameVerify = findViewById(R.id.tvUsernameVerify);
        TextView tvPhoneVerify = findViewById(R.id.tvPhoneVerify);
        TextView tvPasswordVerify = findViewById(R.id.tvPasswordVerify);
        UsersDatabaseHelper usersDatabaseHelper = new UsersDatabaseHelper(RegisterActivity.this);

        btnNewRegister.setEnabled(false);
        etRegisterUserName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() > 0) {
                    if (usersDatabaseHelper.querySingleColumn(charSequence.toString(), "USERNAME")) {
                        btnNewRegister.setEnabled(false);
                        tvUsernameVerify.setText(R.string.username_taken);
                        tvUsernameVerify.setTextColor(Color.parseColor("#FFFE4314"));
                    } else {
                        btnNewRegister.setEnabled(true);
                        tvUsernameVerify.setText(R.string.valid_username);
                        tvUsernameVerify.setTextColor(Color.parseColor("#FF00C300"));
                    }
                } else {
                    btnNewRegister.setEnabled(false);
                    tvUsernameVerify.setText(R.string.enter_username);
                    tvUsernameVerify.setTextColor(Color.parseColor("#FFFE4314"));
            }}
            @Override
            public void afterTextChanged(Editable editable) {
            }
        });

        etRegisterPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() > 0) {
                    btnNewRegister.setEnabled(true);
                    tvPasswordVerify.setText(R.string.password_valid);
                    tvPasswordVerify.setTextColor(Color.parseColor("#FF00C300"));
                } else {
                    btnNewRegister.setEnabled(false);
                    tvPasswordVerify.setText(R.string.password_invalid);
                    tvPasswordVerify.setTextColor(Color.parseColor("#FFFE4314"));
            }}
            @Override
            public void afterTextChanged(Editable editable) {}
        });

        etRegisterPhone.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {}
            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (charSequence.length() > 9) {
                    if (usersDatabaseHelper.querySingleColumn(charSequence.toString(), "PHONE")) {
                        btnNewRegister.setEnabled(false);
                        tvPhoneVerify.setText(R.string.invalid_phone);
                        tvPhoneVerify.setTextColor(Color.parseColor("#FFFE4314"));
                    } else {
                        btnNewRegister.setEnabled(true);
                        tvPhoneVerify.setText(R.string.valid_phone);
                        tvPhoneVerify.setTextColor(Color.parseColor("#FF00C300"));
                    }
                } else {
                    btnNewRegister.setEnabled(false);
                    tvPhoneVerify.setText(R.string.enter_phone);
                    tvPhoneVerify.setTextColor(Color.parseColor("#FFFE4314"));
            }}
            @Override
            public void afterTextChanged(Editable editable) {}
        });

        btnNewRegister.setOnClickListener(v -> {
            String registerUsername = etRegisterUserName.getText().toString();
            String registerPassword = etRegisterPassword.getText().toString();
            String registerPhone = etRegisterPhone.getText().toString();
            // If the Edit Texts are not empty create new user.
            if (!registerUsername.isEmpty() && !registerPassword.isEmpty() && !registerPhone.isEmpty()) {
                Users user = new Users(-1, registerUsername, registerPassword, registerPhone);
                usersDatabaseHelper.addUser(user);

                // Enables Login after first time registration and stores phone to send SMS.
                SharedPreferences.Editor editor = getSharedPreferences("userpref", MODE_PRIVATE).edit();
                editor.putBoolean("enableLogin", true);
                editor.putString("smsPhone",etRegisterPhone.getText().toString());
                editor.apply();

                openMainActivity(registerUsername);
            } else if (registerUsername.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Registration Username Required", Toast.LENGTH_LONG).show();
            } else if (registerPassword.isEmpty()) {
                Toast.makeText(RegisterActivity.this, "Registration Password Required", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(RegisterActivity.this, "Registration Phone Required", Toast.LENGTH_SHORT).show();
            }
        });
    }
    // Passing the intent and extra for the AlertDialog for SMS Notifications in addition to starting the main activity.
    public void openMainActivity(String username) {
        String ID = "Register";
        Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("ID", ID);
            intent.putExtra("username", username);
        startActivity(intent);
    }
}