package com.example.drescheetzoption2;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class Events {
    private final int eventId;
    private String summary, description, eventDateTime, notifDateTime;
    LocalDate eventDate, notifDate;
    LocalTime eventTime, notifTime;
    private boolean expandable;

    // Constructor
    public Events(int eventId, String summary, String description, String eventDateTime, String notifDateTime) {
        this.eventId = eventId;
        this.summary = summary;
        this.description = description;
        this.eventDateTime = eventDateTime;
        this.eventDate = getDate(eventDateTime);
        this.eventTime = getTime(eventDateTime);
        this.notifDateTime = notifDateTime;
        this.notifDate = getDate(notifDateTime);
        this.notifTime = getTime(notifDateTime);
        this.expandable = false;
    }
    // Converts LocalDateTime to LocalTime
    private LocalTime getTime(String dateTime) {
        return LocalDateTime.parse(dateTime,DateTimeFormatter.ISO_LOCAL_DATE_TIME).toLocalTime();
    }
    // Converts LocalDateTime to LocalDate
    private LocalDate getDate(String dateTime) {
        return LocalDateTime.parse(dateTime,DateTimeFormatter.ISO_LOCAL_DATE_TIME).toLocalDate();
    }

    // Getters and Setters
    public int getEventId() { return eventId; }

    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getEventDateTime() { return eventDateTime;}
    public void setEventDateTime(String eventDateTime) { this.eventDateTime = eventDateTime; }
    public LocalDate getEventDate() { return eventDate; }
    public void setEventDate(LocalDate eventDate) { this.eventDate = eventDate; }
    public LocalTime getEventTime() { return eventTime; }
    public void setEventTime(LocalTime eventTime) { this.eventTime = eventTime; }

    public String getNotifDateTime() { return notifDateTime; }
    public void setNotifDateTime(String notifDateTime) { this.notifDateTime = notifDateTime; }
    public LocalDate getNotifDate() { return notifDate; }
    public void setNotifDate(LocalDate notifDate) { this.notifDate = notifDate; }
    public LocalTime getNotifTime() { return notifTime; }
    public void setNotifTime(LocalTime notifTime) { this.notifTime = notifTime; }

    public boolean isExpandable() { return expandable; }
    public void setExpandable(boolean expandable) { this.expandable = expandable; }

    @NonNull
    @Override
    public String toString() {
        return "Events{" +
                " eventId='" + eventId + '\'' +
                ", summary='" + summary + '\'' +
                ", description='" + description + '\'' +
                ", eventDateTime='" + eventDateTime + '\'' +
                ", notifDateTime='" + notifDateTime + '\'' +
                '}';
    }
    // If user sets expanded to false, sets the date & time to database's date & time.
    public void resetEventDateTime(LocalDate localDate, LocalTime localTime, String dateTime) {
        LocalDateTime ldt = LocalDateTime.parse(dateTime,DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        LocalDate date = ldt.toLocalDate();
        LocalTime time = ldt.toLocalTime();
        if (!date.equals(localDate)) {
           setEventDate(date);
        }
        if (!time.equals(localTime)) {
            setEventTime(time);
        }
    }

    // Resets the values for event if not saved when expanded view is collapsed.
    public void resetNotifDateTime(LocalDate localDate, LocalTime localTime, String dateTime) {
        LocalDateTime ldt = LocalDateTime.parse(dateTime,DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        LocalDate date = ldt.toLocalDate();
        LocalTime time = ldt.toLocalTime();
        if (!date.equals(localDate)) {
            setNotifDate(date);
        }
        if (!time.equals(localTime)) {
            setNotifTime(time);
        }
    }

    // Manages when the SMS is to be sent along with the SMS content.
    public void setAlarmSMS(LocalDateTime notifDateTime, int eventId, String eventTitle, String eventDateTime ){
        AlarmManager alarmManager = (AlarmManager) MyApplication.getContext().getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(MyApplication.getContext(), AlarmReceiver.class);
            intent.putExtra("eventTitle", eventTitle);
            intent.putExtra("eventDateTime", eventDateTime);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(MyApplication.getContext(), eventId, intent, 0 );
        long alarm = notifDateTime.atZone(ZoneId.systemDefault()).toEpochSecond();
        // Checks permission before setting the alarm
        if(checkPermissions(Manifest.permission.SET_ALARM)) {
            alarmManager.set(AlarmManager.RTC, alarm, pendingIntent);
            Log.d("Event", notifDateTime.atZone(ZoneId.systemDefault()).toString() + eventId);
        } else {
            Toast.makeText(MyApplication.getContext(), "Missing Alert Permission", Toast.LENGTH_SHORT).show();
        }
    }
    public boolean checkPermissions(String permission){
        int check = ContextCompat.checkSelfPermission(MyApplication.getContext(), permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
}
