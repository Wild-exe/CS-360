package com.example.drescheetzoption2;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        EditText etUserName = findViewById(R.id.etUsername);
        EditText etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);


        SharedPreferences prefs = getSharedPreferences("userpref", MODE_PRIVATE);
        boolean registered = prefs.getBoolean("enableLogin", false);
        if(registered){
            etUserName.setEnabled(true);
            etPassword.setEnabled(true);
            btnLogin.setEnabled(true);
        }

        btnLogin.setOnClickListener(v -> {
            String username = etUserName.getText().toString();
            String password = etPassword.getText().toString();
            if (!username.isEmpty() && !password.isEmpty() ) {
                UsersDatabaseHelper usersDatabaseHelper = new UsersDatabaseHelper(LoginActivity.this);
                if (usersDatabaseHelper.queryUserExists(username, password)) {
                    openMainActivity(username);
                } else {
                    Toast.makeText(this, "Username or Password Incorrect", Toast.LENGTH_LONG).show();
                }
            } else if (username.isEmpty() ) {
                Toast.makeText(this, "Login Username Required", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Login Password Required", Toast.LENGTH_LONG).show();
            }
        });

        Button btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(v -> openRegisterActivity());

    }
    // Activity Method
    public void openMainActivity(String username) {
        //Currently unused; however, the extra intent is to prevent crash.
        String ID = "Login";
        Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("ID", ID);
            intent.putExtra("username", username);
        startActivity(intent);
    }
    public void openRegisterActivity() {
        Intent intent = new Intent(this, RegisterActivity.class);
        startActivity(intent);
    }
}