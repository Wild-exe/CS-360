package com.example.drescheetzoption2;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.core.content.ContextCompat;

public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        // Context provided by Singleton.
        String smsReceiver = MyApplication.getContext().getSharedPreferences("userpref", 0).getString("smsPhone", null);
        // From intent get the values of the event to be displayed in SMS Notification.
        String eventTitle = intent.getStringExtra("eventTitle");
        String eventDateTime = intent.getStringExtra("eventDateTime");
        String smsMsg = "Reminder, " + eventTitle + " is scheduled on: " + eventDateTime + ". Check event in app for more details.";
        Log.d("Event Receiver", "onReceive");
       // Ensures permission before attempting to send SMS Notification.
        if(checkPermissions(Manifest.permission.SEND_SMS)){
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(smsReceiver, null, smsMsg, null, null);
            Log.d("Event Notification", "SMS Sent");
        } else {
            Log.d("Event Notification", "SMS Permission Denied");
        }
    }
    public boolean checkPermissions(String permission){
        int check = ContextCompat.checkSelfPermission(MyApplication.getContext(), permission);
        return (check == PackageManager.PERMISSION_GRANTED);
    }
}
